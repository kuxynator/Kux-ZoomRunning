# Kuxynator's Zoom-Running

Running speed depends on zoom level. Zoom out to run faster, zoom in to run slower.

##  Info

- This mod is a join of [Kuxynator's Running (Cheat Mode))](https://mods.factorio.com/mod/Kux-RunningCheat) and the always required mod [Zooming Reinvented](https://mods.factorio.com/mod/Kux-Zooming). 
For a detailed description see there.
- It is planned to limit the maximum speed to the actual possible maximum speed (with exoskeleton).