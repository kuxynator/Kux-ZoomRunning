require "modules.PlayerMemory"

local this = nil

local data = {
	--- Gets a value indicating wether the mod Kux-Zooming is available.
	isAvailabe = false,
}

--- kuxZooming module
-- @module: kuxZooming
KuxZooming = {
	moduleName = "kuxZooming",

	initialize = function (eventName)
		log("initialize("..eventName..")")
		--Log.trace(moduleName..".initialize")
		local isAvailabe = script.active_mods["Kux-Zooming"] ~= nil
		if isAvailabe then
			remote.add_interface(this.interfaceName, this.interface)
		end

		this.onZoomFactorChanged_register()

		if script.active_mods["creative-mod"] ~= nil then
			remote.call("creative-mode","register_remote_function_to_modding_ui",
						this.interfaceName, "test")
			-- remote.call("creative-mode","deregister_remote_function_from_modding_ui",
			--			this.interfaceName, "onZoomFactorChanged")
		end
	end,

	interfaceName = "Kux-Running2-Kux-Zooming-Callback",
	interface = {
		onZoomFactorChanged = function(event)			
			local zoomFactor = event.zoomFactor
			local renderMode = event.renderMode
			local playerIndex = event.playerIndex
			if event.creative_mode_modding then
				playerIndex = event.player_index
			end

			--print("onZoomFactorChanged",zoomFactor,renderMode)
			log("interface.onZoomFactorChanged({"..zoomFactor..", "..renderMode.."})")
			local player = game.players[playerIndex]
			local pm = PlayerMemory.get(player)
			pm.renderMode = renderMode
			pm.zoomFactor = zoomFactor

			if not player.character or renderMode ~= defines.render_mode.game then return end

			local modifier = (1/zoomFactor) * Settings.getZoomSpeedModificator(player) * Settings.getUpsAdjustment(player) -1
			pm.speedModifier = modifier
			if Settings.getDisableRunningSpeedModifier(player) ~= true then
				player.character_running_speed_modifier = pm.speedModifier
				log("onZoomFactorChanged: "..zoomFactor..", character_running_speed_modifier:"..modifier..", player:"..event.playerIndex)
				--player.print("onZoomFactorChanged: "..zoomFactor..", character_running_speed_modifier:"..modifier)
			end
			--print("character_running_speed_modifier", pm.speedModifier)
		end,

		test = function(args)
			local player = game.players[args.player_index]
			player.character_running_speed_modifier = 2			
		end
	},

	--- registers the onZoomFactorChanged callback
	onZoomFactorChanged_register = function ()
		--print("onZoomFactorChanged_register")
		if data.onZoomFactorChanged_registered then return end
		remote.call("Kux-Zooming", "onZoomFactorChanged_add", this.interfaceName, "onZoomFactorChanged")
		this.onZoomFactorChanged_registered = true
	end,

	onZoomFactorChanged_remove = function ()
		if data.onZoomFactorChanged_registered then return end
		if not data.isAvailabe then return end
		remote.call("Kux-Zooming", "onZoomFactorChanged_remove", this.interfaceName)
		data.onZoomFactorChanged_registered = false
	end,

	--- Gets the current zoom factor of the specified player
	-- @player: LuaPlayer
	getZoomFactor = function(player)
		return remote.call("Kux-Zooming", "getZoomFactor", player.index)
	end,

	initPlayer = function (player)
		log("initPlayer()")
		if player.render_mode == defines.render_mode.game then
			local zoomFactor = this.getZoomFactor(player)
			this.interface.onZoomFactorChanged({
				playerIndex = player.index,
				zoomFactor  = zoomFactor,
				renderMode  = player.render_mode
			})
		end
	end
}
this = KuxZooming -- init local this